function createEventhandler(element) {
	let menuElement = element;
	function handler(event) {
		let titleElement = menuElement.querySelector('.title');
		if (event.target == titleElement) {
			if (menuElement.className == 'hamburger') {
				menuElement.className = 'hamburger open';
			} else {
				menuElement.className = 'hamburger';
			}
		}
	}
	return handler;
}

let menuElements = document.querySelectorAll('.menus .hamburger');
menuElements.forEach(function(element){
    element.onclick = createEventhandler(element);
});